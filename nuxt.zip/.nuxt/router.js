import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _fe6b9580 = () => interopDefault(import('../pages/cal.vue' /* webpackChunkName: "pages/cal" */))
const _c8752148 = () => interopDefault(import('../pages/call.vue' /* webpackChunkName: "pages/call" */))
const _b980a29c = () => interopDefault(import('../pages/cur.vue' /* webpackChunkName: "pages/cur" */))
const _6e6e220c = () => interopDefault(import('../pages/privacy.vue' /* webpackChunkName: "pages/privacy" */))
const _61b4ff90 = () => interopDefault(import('../pages/test.vue' /* webpackChunkName: "pages/test" */))
const _247ea478 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/cal",
    component: _fe6b9580,
    name: "cal"
  }, {
    path: "/call",
    component: _c8752148,
    name: "call"
  }, {
    path: "/cur",
    component: _b980a29c,
    name: "cur"
  }, {
    path: "/privacy",
    component: _6e6e220c,
    name: "privacy"
  }, {
    path: "/test",
    component: _61b4ff90,
    name: "test"
  }, {
    path: "/",
    component: _247ea478,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}

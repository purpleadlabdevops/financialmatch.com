export const Footer = () => import('../../components/Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const Header = () => import('../../components/Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const Section1 = () => import('../../components/Section1.vue' /* webpackChunkName: "components/section1" */).then(c => wrapFunctional(c.default || c))
export const Section2 = () => import('../../components/Section2.vue' /* webpackChunkName: "components/section2" */).then(c => wrapFunctional(c.default || c))
export const Section3 = () => import('../../components/Section3.vue' /* webpackChunkName: "components/section3" */).then(c => wrapFunctional(c.default || c))
export const Section4 = () => import('../../components/Section4.vue' /* webpackChunkName: "components/section4" */).then(c => wrapFunctional(c.default || c))
export const Section5 = () => import('../../components/Section5.vue' /* webpackChunkName: "components/section5" */).then(c => wrapFunctional(c.default || c))
export const Section6 = () => import('../../components/Section6.vue' /* webpackChunkName: "components/section6" */).then(c => wrapFunctional(c.default || c))
export const Section7 = () => import('../../components/Section7.vue' /* webpackChunkName: "components/section7" */).then(c => wrapFunctional(c.default || c))
export const Top = () => import('../../components/Top.vue' /* webpackChunkName: "components/top" */).then(c => wrapFunctional(c.default || c))
export const WithVideo = () => import('../../components/WithVideo.vue' /* webpackChunkName: "components/with-video" */).then(c => wrapFunctional(c.default || c))
export const Faq = () => import('../../components/faq.vue' /* webpackChunkName: "components/faq" */).then(c => wrapFunctional(c.default || c))
export const CalendlyCal = () => import('../../components/Calendly/Cal.vue' /* webpackChunkName: "components/calendly-cal" */).then(c => wrapFunctional(c.default || c))
export const CalendlyCalext = () => import('../../components/Calendly/Calext.vue' /* webpackChunkName: "components/calendly-calext" */).then(c => wrapFunctional(c.default || c))
export const ThanksCal = () => import('../../components/Thanks/Cal.vue' /* webpackChunkName: "components/thanks-cal" */).then(c => wrapFunctional(c.default || c))
export const ThanksCalext = () => import('../../components/Thanks/Calext.vue' /* webpackChunkName: "components/thanks-calext" */).then(c => wrapFunctional(c.default || c))
export const ThanksCall = () => import('../../components/Thanks/Call.vue' /* webpackChunkName: "components/thanks-call" */).then(c => wrapFunctional(c.default || c))
export const ThanksCur = () => import('../../components/Thanks/Cur.vue' /* webpackChunkName: "components/thanks-cur" */).then(c => wrapFunctional(c.default || c))
export const ThanksMain = () => import('../../components/Thanks/Main.vue' /* webpackChunkName: "components/thanks-main" */).then(c => wrapFunctional(c.default || c))
export const QuizuiForm = () => import('../../components/quizui/form.vue' /* webpackChunkName: "components/quizui-form" */).then(c => wrapFunctional(c.default || c))
export const BlocksBtn = () => import('../../components/blocks/Btn.vue' /* webpackChunkName: "components/blocks-btn" */).then(c => wrapFunctional(c.default || c))
export const BlocksVideoFrame = () => import('../../components/blocks/VideoFrame.vue' /* webpackChunkName: "components/blocks-video-frame" */).then(c => wrapFunctional(c.default || c))
export const BlocksFaq = () => import('../../components/blocks/faq.vue' /* webpackChunkName: "components/blocks-faq" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}

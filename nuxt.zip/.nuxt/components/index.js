export const Footer = () => import('../../components/Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const Header = () => import('../../components/Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const Section1 = () => import('../../components/Section1.vue' /* webpackChunkName: "components/section1" */).then(c => wrapFunctional(c.default || c))
export const Section2 = () => import('../../components/Section2.vue' /* webpackChunkName: "components/section2" */).then(c => wrapFunctional(c.default || c))
export const Section3 = () => import('../../components/Section3.vue' /* webpackChunkName: "components/section3" */).then(c => wrapFunctional(c.default || c))
export const Section4 = () => import('../../components/Section4.vue' /* webpackChunkName: "components/section4" */).then(c => wrapFunctional(c.default || c))
export const Section5 = () => import('../../components/Section5.vue' /* webpackChunkName: "components/section5" */).then(c => wrapFunctional(c.default || c))
export const Section6 = () => import('../../components/Section6.vue' /* webpackChunkName: "components/section6" */).then(c => wrapFunctional(c.default || c))
export const Section7 = () => import('../../components/Section7.vue' /* webpackChunkName: "components/section7" */).then(c => wrapFunctional(c.default || c))
export const Top = () => import('../../components/Top.vue' /* webpackChunkName: "components/top" */).then(c => wrapFunctional(c.default || c))
export const WithVideo = () => import('../../components/WithVideo.vue' /* webpackChunkName: "components/with-video" */).then(c => wrapFunctional(c.default || c))
export const Faq = () => import('../../components/faq.vue' /* webpackChunkName: "components/faq" */).then(c => wrapFunctional(c.default || c))
export const CalendlyCal = () => import('../../components/Calendly/Cal.vue' /* webpackChunkName: "components/calendly-cal" */).then(c => wrapFunctional(c.default || c))
export const CalendlyCalext = () => import('../../components/Calendly/Calext.vue' /* webpackChunkName: "components/calendly-calext" */).then(c => wrapFunctional(c.default || c))
export const GreencallContent = () => import('../../components/Greencall/Content.vue' /* webpackChunkName: "components/greencall-content" */).then(c => wrapFunctional(c.default || c))
export const GreencallFooter = () => import('../../components/Greencall/Footer.vue' /* webpackChunkName: "components/greencall-footer" */).then(c => wrapFunctional(c.default || c))
export const GreencallHeader = () => import('../../components/Greencall/Header.vue' /* webpackChunkName: "components/greencall-header" */).then(c => wrapFunctional(c.default || c))
export const PartialsModal = () => import('../../components/Partials/Modal.vue' /* webpackChunkName: "components/partials-modal" */).then(c => wrapFunctional(c.default || c))
export const PartialsPopups = () => import('../../components/Partials/Popups.vue' /* webpackChunkName: "components/partials-popups" */).then(c => wrapFunctional(c.default || c))
export const QuizuiForm = () => import('../../components/quizui/form.vue' /* webpackChunkName: "components/quizui-form" */).then(c => wrapFunctional(c.default || c))
export const BlocksBtn = () => import('../../components/blocks/Btn.vue' /* webpackChunkName: "components/blocks-btn" */).then(c => wrapFunctional(c.default || c))
export const BlocksVideoFrame = () => import('../../components/blocks/VideoFrame.vue' /* webpackChunkName: "components/blocks-video-frame" */).then(c => wrapFunctional(c.default || c))
export const BlocksFaq = () => import('../../components/blocks/faq.vue' /* webpackChunkName: "components/blocks-faq" */).then(c => wrapFunctional(c.default || c))
export const ThanksCal = () => import('../../components/Thanks/Cal.vue' /* webpackChunkName: "components/thanks-cal" */).then(c => wrapFunctional(c.default || c))
export const ThanksCalext = () => import('../../components/Thanks/Calext.vue' /* webpackChunkName: "components/thanks-calext" */).then(c => wrapFunctional(c.default || c))
export const ThanksCall = () => import('../../components/Thanks/Call.vue' /* webpackChunkName: "components/thanks-call" */).then(c => wrapFunctional(c.default || c))
export const ThanksCur = () => import('../../components/Thanks/Cur.vue' /* webpackChunkName: "components/thanks-cur" */).then(c => wrapFunctional(c.default || c))
export const ThanksMain = () => import('../../components/Thanks/Main.vue' /* webpackChunkName: "components/thanks-main" */).then(c => wrapFunctional(c.default || c))
export const SpanishFaq = () => import('../../components/Spanish/Faq.vue' /* webpackChunkName: "components/spanish-faq" */).then(c => wrapFunctional(c.default || c))
export const SpanishForm = () => import('../../components/Spanish/Form.vue' /* webpackChunkName: "components/spanish-form" */).then(c => wrapFunctional(c.default || c))
export const SpanishMain = () => import('../../components/Spanish/Main.vue' /* webpackChunkName: "components/spanish-main" */).then(c => wrapFunctional(c.default || c))
export const SpanishSection1 = () => import('../../components/Spanish/Section1.vue' /* webpackChunkName: "components/spanish-section1" */).then(c => wrapFunctional(c.default || c))
export const SpanishSection2 = () => import('../../components/Spanish/Section2.vue' /* webpackChunkName: "components/spanish-section2" */).then(c => wrapFunctional(c.default || c))
export const SpanishSection3 = () => import('../../components/Spanish/Section3.vue' /* webpackChunkName: "components/spanish-section3" */).then(c => wrapFunctional(c.default || c))
export const SpanishSection4 = () => import('../../components/Spanish/Section4.vue' /* webpackChunkName: "components/spanish-section4" */).then(c => wrapFunctional(c.default || c))
export const SpanishSection5 = () => import('../../components/Spanish/Section5.vue' /* webpackChunkName: "components/spanish-section5" */).then(c => wrapFunctional(c.default || c))
export const SpanishSection6 = () => import('../../components/Spanish/Section6.vue' /* webpackChunkName: "components/spanish-section6" */).then(c => wrapFunctional(c.default || c))
export const SpanishSection7 = () => import('../../components/Spanish/Section7.vue' /* webpackChunkName: "components/spanish-section7" */).then(c => wrapFunctional(c.default || c))
export const SpanishTop = () => import('../../components/Spanish/Top.vue' /* webpackChunkName: "components/spanish-top" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}

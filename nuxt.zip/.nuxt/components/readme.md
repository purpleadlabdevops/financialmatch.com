# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Footer>` | `<footer>` (components/Footer.vue)
- `<Header>` | `<header>` (components/Header.vue)
- `<Section1>` | `<section1>` (components/Section1.vue)
- `<Section2>` | `<section2>` (components/Section2.vue)
- `<Section3>` | `<section3>` (components/Section3.vue)
- `<Section4>` | `<section4>` (components/Section4.vue)
- `<Section5>` | `<section5>` (components/Section5.vue)
- `<Section6>` | `<section6>` (components/Section6.vue)
- `<Section7>` | `<section7>` (components/Section7.vue)
- `<Top>` | `<top>` (components/Top.vue)
- `<WithVideo>` | `<with-video>` (components/WithVideo.vue)
- `<Faq>` | `<faq>` (components/faq.vue)
- `<CalendlyCal>` | `<calendly-cal>` (components/Calendly/Cal.vue)
- `<CalendlyCalext>` | `<calendly-calext>` (components/Calendly/Calext.vue)
- `<ThanksCal>` | `<thanks-cal>` (components/Thanks/Cal.vue)
- `<ThanksCalext>` | `<thanks-calext>` (components/Thanks/Calext.vue)
- `<ThanksCall>` | `<thanks-call>` (components/Thanks/Call.vue)
- `<ThanksCur>` | `<thanks-cur>` (components/Thanks/Cur.vue)
- `<ThanksMain>` | `<thanks-main>` (components/Thanks/Main.vue)
- `<BlocksBtn>` | `<blocks-btn>` (components/blocks/Btn.vue)
- `<BlocksVideoFrame>` | `<blocks-video-frame>` (components/blocks/VideoFrame.vue)
- `<BlocksFaq>` | `<blocks-faq>` (components/blocks/faq.vue)
- `<QuizuiForm>` | `<quizui-form>` (components/quizui/form.vue)
